
package proyecto.pkgfinal;

import Jframes.FPrincipal;

public class ProyectoFinalSI {

   
    public static void main(String[] args) {
 FPrincipal P = new FPrincipal();
 P.setVisible(true);
 
 
    }
   
    
}
